$(document).ready(function () {
    window.scrollTo({top: 0, behavior: 'smooth'});
    $(".second-button").on("click", function () {
        $(".animated-icon2").toggleClass("open");
    });
    $("#navLinkBeginner").click(function(){
        $("#navLinkExpert").removeClass("active");
        $("#navLinkBeginner").addClass("active");
    })
    $("#navLinkExpert").click(function(){
        $("#navLinkBeginner").removeClass("active");
        $("#navLinkExpert").addClass("active");
    })
    $("#navLinkBeginner").click(function(){
        $("#beginners").addClass("show active");
        $("#expert").removeClass("show active");
    })
    $("#navLinkExpert").click(function(){
        $("#beginners").removeClass("show active");
        $("#expert").addClass("show active");
    })
    $(".header-buttom").scroll(function(){
        $(".header-buttom")
    });
    $(window).bind('scroll', function() {
        var navHeight = $( window ).height() - 600;
              if ($(window).scrollTop() > navHeight) {
                  $('.header-buttom').addClass('scroll');
                }
                else {
                    $('.header-buttom').removeClass('scroll');
              }
         });
});
